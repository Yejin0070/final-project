export default function SideBarItem({ menu, isActive }) {
  return isActive === true ? (
    <div className="sideBarItemActive">
      <p>{menu.name}</p>
    </div>
  ) : (
    <div className="SideBarItem">
      <p>{menu.name}</p>
    </div>
  );
}
