import "../../style/sideBar.css";
import { Link, useLocation, useParams } from "react-router-dom";
import SideBarItem from "./sideBarItem";

export default function SideBar(country) {
  const pathName = useLocation().pathname;
  let { cur_unit } = useParams;

  const menus = [
    { name: "나라 전체 보기", path: "/" },
    { name: "환율 상세 보기", path: "/country/:cur_unit" },
    { name: "그래프 보기", path: "/graph/:cur_unit" },
  ];

  return (
    <div className="sideBar">
      <h3>Exchange Rate Village</h3>
      {menus.map((menu, index) => {
        return (
          <Link to={menu.path} key={index}>
            <SideBarItem
              menu={menu}
              isActive={pathName === menu ? true : false}
            ></SideBarItem>
          </Link>
        );
      })}
    </div>
  );
}
