import "../../style/common.css";
export default function GraphPage() {
  return <div></div>;
}
